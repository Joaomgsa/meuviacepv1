package br.com.meuviacep;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeuviacepApplication {

	public static void main(String[] args) {
		SpringApplication.run(MeuviacepApplication.class, args);
	}

}
